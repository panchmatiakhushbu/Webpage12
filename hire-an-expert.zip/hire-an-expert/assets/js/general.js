if (!("ontouchstart" in document.documentElement)) {
    document.documentElement.className += " no-touch";
} else {
    document.documentElement.className += " touch";
}

(function($) {
    /*Initializing START*/

    $(document).ready(function () {
        $(".hide-show-pass-btn").click(function () {
            $(this).parents('.password-input-wrap').toggleClass("show");
        });
        $('.nav-toggle-btn').click(function () {
            $('.logo-wrap').toggleClass('active');
            $('.left-sidebar').toggleClass('active');
            $('.page-wrapper').toggleClass('active'); 
            $('.nav-wrap').toggleClass('active');
        });
        $("header .has-search .icon-search-icon, header .has-search .form-control").click(function () {
            $(this).parents('header .has-search').addClass("active");
        });
        $("header .has-search .close-btn").click(function () {
            $(this).parents('header .has-search').removeClass("active");
        });
        $(".text-more").click(function () {
            if ($(this).hasClass('active')) {
                $(this).text('More');
                $(this).removeClass('active');
                $('.content-area .info' ).removeClass('active');
            } else {
                $(this).text('Less');
                $(this).addClass('active');
                $('.content-area .info').addClass('active');
                
            }
        });
        $('.filter-toggle').click(function () {
            $('.filter-sidebar').toggleClass('active');
            $('.inquiries-wrapper').toggleClass('active'); 
        });
      
      // $('.common-tabs .nav-link').click(function () {
      //   $(this).parents('.common-tabswrapper').toggleClass('active');
      //     // if ($(this).hasClass('active')) {
      //     //   $(this).parents('.common-tabswrapper').addClass('active');
            
      //     // } else {
            
      //     //   // $('.common-tabs .nav-link').removeClass('active');
      //     //   // $(this).addClass('active');
      //     //   $(this).parents('.common-tabswrapper').removeClass('active');
      //     // }
      // });
        

      //Date picker js
      $( function() {
          var dateFormat = "mm/dd/yy",
            from = $( "#from-date" )
              .datepicker({
                defaultDate: "+1w",
                changeMonth: true,
                numberOfMonths: 1
              })
              .on( "change", function() {
                to.datepicker( "option", "minDate", getDate( this ) );
              }),
            to = $( "#to-date" ).datepicker({
              defaultDate: "+1w",
              changeMonth: true,
              numberOfMonths: 1
            })
            .on( "change", function() {
              from.datepicker( "option", "maxDate", getDate( this ) );
            });
        
          function getDate( element ) {
            var date;
            try {
              date = $.datepicker.parseDate( dateFormat, element.value );
            } catch( error ) {
              date = null;
            }
        
            return date;
          }
      });
      
      
    });





    $(window).on("load",function() {
    });

    $(window).on("resize", function() {
    });
})(jQuery);
/*Initializing END*/