# Introduction 

# Getting Started
Guide users through getting your code up and running on their own system. In this section you can talk about:
1. __Software dependencies__
  

2. __Installation process__
   * Repo is located [here](http://git.indianic.com/BRJFSCL0/F2021-6036/html19).
   * `git clone` the repo. 
   * Work under the context `<REPO>\html`

# Build and Test
Currently, there are no unit test.

# Knowledge Base
## Technology Stack
* Web Front End - HTML5 and SASS

## GIT
1. __Pull Requests__
   All code merged to `staging` branch needs to go through the pull request process.

2. __Branch Names__
   
3. gitignore
   - All complied file added in .gitignore file 
        
## Folder Structure
* `configs` - Configurations for application.
* `Project` - 
      `assets`/
      ├── `css`/
      │   ├── style.css ( Note: all compiled css)
      ├── `fonts`/
      │   ├── All Font files
      ├── `img`/
      └── `js`/
      |   ├── javascript-lib.js ( Note: all compiled js)
      |   ├── General.js
      └── `scss`/
      |   ├── component
      |   |   ├── all.scss (all component file import here)
      |   |   ├── footer.scss
      |   |   ├── form-button.scss
      |   |   ├── header.scss
      |   ├── helpers
      |   |   ├── functions.scss 
      |   |   ├── import.scss 
      |   |   ├── mixin.scss
      |   |   ├── typography.scss
      |   |   ├── variable.scss ( this file import at sass/style.scss for bootstraps variable overwrite)
      |   ├── style.scss (Main Scss File)
      ├── .gitignore
      ├── favicon.ico
      ├── HTML Pages
      ├── README.md
* `environments` - Environment configuration for DEV/QA/PROD.

## Styles & Themes
## Bootstrap Style Guide
A coding style guide can be found [here](https://getbootstrap.com/).

# Vendor Dependencies
- [bootstrap](https://getbootstrap.com/)
- [popper.js](https://popper.js.org/docs/v2/)
	Why Popper?
	With the CSS drawbacks out of the way, we now move on to Popper in the JavaScript space itself.
	Naive JavaScript tooltip implementations usually have the following problems:
	Scrolling containers: They don't ensure the tooltip stays with the reference element while scrolling when inside any number of scrolling containers.
	DOM context: They often require the tooltip move outside of its original DOM context because they don't handle offsetParent contexts.
	Configurability: They often lack advanced configurability to suit any possible use case.
	Size: They are usually relatively large in size, or require an ancient jQuery dependency.
	Performance: They often have runtime performance issues and update the tooltip position too slowly.